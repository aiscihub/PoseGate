# Cohort Expansion to 80: Status and To-Do

Snapshot date: 2026-07-19 (updated; was 2026-07-17).

## Where things stand

The locked headline analysis (52 trajectories, 15 proteins, 13 retained / 39
non-retained) in `yau_aj.tex` (renamed from `yau_aj_trajectory_triage.tex`) is
not disturbed by anything below. The 100 ns primary cohort is being expanded
(52 -> 73 -> 76 now -> 80 target). The 100 ns side is self-contained and does
not depend on any other dataset.

**Why 52 stayed locked instead of just growing in place:** freezing before
further analysis is what makes the headline AUROC/CI numbers trustworthy --
if the "locked" cohort could just be enlarged whenever new trajectories
finish, the reported numbers would be quietly re-tuned by whichever data
happens to exist, which is a real statistical hazard (undisclosed multiple
looks / optional stopping). It was never a claim that 52 is a ceiling. Two
things matter for what happens after 80, captured in the priority list below:
most of the growth from 52 onward is more pockets/replicas on the *same*
15-16 proteins rather than new proteins (LOPO validation is protein-clustered,
so protein count -- not trajectory count -- is what actually buys statistical
power), and the locked 52 went through a heavier QC/redundancy-audit chain
(scripts 25-27: outcome-redundancy audit, SHA-256-pinned source-artifact
manifest, legacy-number reconciliation) than the expanded cohort's simpler
direct-discovery pipeline (script 28) has had. Promoting the expanded cohort
to primary status without that same audit layer would quietly weaken the
provenance story even if the numbers looked fine.

The one claim that does **not** automatically scale with the primary cohort is
same-trajectory-vs-separate-launch transfer, because it needs a second,
independently launched 20 ns trajectory per complex. That 20 ns dataset lives
on the Linux host only, at
`/media/zhenli/datadrive/valleyfevermutation/simulation_20ns_md/`, not on this
mounted share.

## What we verified this session

1. **Protein composition of the 52 -> 73 expansion.** Of the 21 trajectories
   added since the lock, only one is a genuinely new protein (`CIMG_06197`,
   contributing 5 rows). The other ~16 new rows are additional
   pockets/replicas on the 15 proteins already in the locked cohort. Class
   balance held steady: 13/39 retained (25.0%) at n=52 vs. 17/56 (23.3%) at
   n=73 -- the base rate is not drifting as the cohort grows.

2. **20 ns separate-launch coverage on disk, checked directly via
   `pipeline/cli/discover_20ns_runs.py` run against the raw drive:**
   - 64 unique protein:pocket pairs have both a topology and trajectory file
     present.
   - Of the 73-trajectory expanded 100 ns cohort, **55/73** already have a
     matching 20 ns separate launch on disk -- no new simulation needed, just
     running the existing measurement/QC pipeline against them.
   - **18/73** have no 20 ns trajectory on disk. 5 of those 18 are all of
     `CIMG_06197`'s pockets (the new protein); the rest are scattered single
     pockets across 8 other proteins.

3. **Fingerprint-sheet backfill for the 18 gap pockets.**
   `pipeline/training/outputs/fingerprint_summary_with_components_even_ac_80_final_result.csv`
   still has precomputed rows for **16 of the 18** gap pockets (raw DCDs were
   evidently deleted after feature extraction). Only `PDH1_CANGA:pocket7` and
   `PDR5_YEAST:pocket11` are missing everywhere -- those two need a fresh 20 ns
   launch if full coverage is ever wanted.

4. **Validated which fingerprint-sheet column is safe to reuse**, by
   comparing against the known-correct `separate_launch_pose_rmsd_18_20_A` /
   `separate_launch_centroid_displacement_18_20_A` columns in
   `same_trajectory_source_of_truth.csv` on the 52 rows where both exist
   (manual AUROC calc reproduced the paper's reported 0.546 exactly, confirming
   the check is apples-to-apples):

   | Feature | Spearman rho vs. true corrected RMSD | AUROC to retained |
   |---|---|---|
   | True separate-launch corrected RMSD (paper's feature) | -- | 0.546 |
   | True separate-launch corrected centroid displacement | -- | 0.538 |
   | `ligand_drift` (protein-Cα-aligned, initial-to-final frame) | 0.437 (p=0.001) | 0.554 |
   | `rmsd_20ns` (ligand-**self**-aligned -- the known-bad control) | 0.450 (p=0.001) | 0.375 |

   `ligand_drift` traces to `measure_drift_from_pdbs` in
   `pipeline/features/mechanical.py`, which aligns on protein backbone first --
   it lands at essentially the same near-chance AUROC as the true feature
   (0.554 vs 0.546), so it is a defensible backfill **for this specific
   near-chance-transfer claim only**. `rmsd_20ns` traces to `compute_rmsd_late`
   in `pipeline/training/v1/compute_ground_truth_labels.py`, which superposes
   the ligand onto itself -- structurally the same "ligand-self-aligned"
   construction the paper's own ablation already showed collapses
   discrimination (AUROC 0.507 in the locked analysis). It must not be used as
   a substitute for anything.

   This validation says nothing about whether `ligand_drift` would hold up for
   the same-trajectory (high-signal) side -- that question doesn't arise since
   the 100 ns cohort is self-contained and isn't being backfilled from this
   sheet.

## Decision

Finish the 100 ns run to 80 first. The separate-launch extension (55 on disk +
16 backfillable via `ligand_drift`, disclosed as a substitute feature, = 71 of
whatever the final 100 ns n turns out to be) is deprioritized until after, since
it is a secondary/supporting comparison, not the primary discrimination claim.

## To-do list, in priority order

1. **Finish the primary 100 ns cohort to 80.** No dependency on anything
   below. (73 as of 2026-07-17; 76 as of 2026-07-19, all growth so far on
   already-represented proteins -- still 16 proteins total.)
2. Once 80 is done, re-run the post-lock-style audit (the same pattern already
   used for the 73- and 76-cohort model-complexity audits) at n=80: raw
   corrected-RMSD AUROC, PBC-naive / ligand-self-aligned controls, and the
   model-complexity comparison. Report side by side with the n=52 locked
   numbers and the n=73/76 numbers already in the draft -- do not silently
   replace the locked headline.
3. **New primary lock at n~80 (decided 2026-07-19).** Rather than quietly
   growing the "locked" 52 in place, or promoting the expanded cohort's
   simpler pipeline to primary status as-is, run the n~80 cohort through the
   same heavier audit chain the original lock used (the script-25-27 pattern:
   outcome-redundancy audit, SHA-256-pinned source-artifact manifest,
   legacy-number reconciliation), not just the expanded cohort's direct
   discovery pipeline (script 28). Present the result as an explicit second
   locked cohort ("locked v2") that supersedes the n=52 lock for the primary
   claim, with the n=52 result kept and clearly labeled as the original/prior
   locked result rather than deleted or silently overwritten. Update every
   place in `yau_aj.tex` that currently cites the n=52 headline numbers to
   either cite locked-v2 instead or explicitly present both side by side, and
   update the Limitations section's characterization of cohort size
   accordingly.
4. Once 80 is locked (per item 3), re-run the pose-decomposition and
   local-pocket-alignment control (`yau_competition/scripts/cad_paper_analysis/`
   scripts 33, 35, 36, 37, 38, and the frozen `[T,Theta]` LOPO joint model in
   34) on the new cohort -- these were explicitly paused mid-conversation on
   2026-07-19 pending the 80-trajectory target and are currently stale
   relative to the 76-trajectory master table. Diff the refreshed AUROC /
   compute-saved / agreement numbers against what's currently written in
   `yau_aj.tex`'s "Pose decomposition identifies rigid-body reorientation..."
   subsection and Supplementary Material before deciding whether the change
   is material enough to warrant a text update (small CI-overlapping shifts,
   as already seen going 73->76, generally do not).
5. **Then**, extend the same-trajectory-vs-separate-launch comparison:
   - Run the existing pairing/QC pipeline (the logic behind
     `same_trajectory_source_of_truth.csv`'s `separate_launch_*` columns)
     against the 55 protein:pocket pairs confirmed present on disk, to get the
     real post-QC usable count (paper's prior experience: ~95% pass rate, so
     expect roughly 52-53 of the 55 to survive).
   - Backfill the 16 fingerprint-only pockets using `ligand_drift`, with the
     disclosure language drafted above.
   - Launch fresh 20 ns runs for `PDH1_CANGA:pocket7` and
     `PDR5_YEAST:pocket11` only if full parity with the 80-cohort is wanted;
     otherwise report the separate-launch comparison at whatever n results
     (expected ceiling: roughly 78/80 protein:pocket pairs).
   - Recompute the paired same-vs-separate-launch AUROC difference and its
     bootstrap CI at the new n, and update Section "Same-run persistence does
     not imply separate-launch predictability" accordingly.
6. Update the manuscript to report the primary discrimination cohort and the
   same-vs-separate-launch cohort at their own, correct, and different sample
   sizes -- do not let the larger number quietly carry both claims.
