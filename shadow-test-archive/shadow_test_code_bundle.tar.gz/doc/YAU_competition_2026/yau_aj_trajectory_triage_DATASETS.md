# Dataset index — `yau_aj_trajectory_triage.tex`

Verified 2026-07-18. Paths are repo-relative. This file exists so the data
backing the paper's claims can be found again without re-deriving the
provenance chain from scratch.

## Status: two cohorts currently exist

The manuscript's **primary claims still cite the locked 52-trajectory
cohort** (first section below). A newer **73-trajectory expanded cohort**
(81 discovered, 73 eligible) exists as an **exploratory** superset and is
not yet what the headline numbers are drawn from — see model-complexity
audit note in the paper (§Results, "expanded 73-trajectory cohort") for the
one place it is currently referenced. Do not conflate the two when citing a
number: check which cohort a table/figure actually used.

## Expanded source-of-truth (latest, exploratory, 73-row primary cohort)

Directory: `pipeline/training/outputs/yau_recapture_screen/cad_states/expanded_source_of_truth/`

Canonical version tag: `expanded_same_trajectory_v1`.

| File | Rows | Purpose |
|---|---|---|
| `master/expanded_trajectory_source_of_truth.csv` | 81 (73 eligible) | Master table, superset of the locked 52-row cohort. Filter on `eligible_primary_cohort == True` for the 73-row primary analysis cohort (16 proteins, 17 late-retained / 56 late-non-retained). Do not infer eligibility from non-null labels — use the explicit flag, audit `primary_exclusion_reason`. **Verified SHA-256 `ccf87e...fde65` matches on disk, 2026-07-18.** |
| `master/build_manifest.json` | — | Build provenance: row/protein/outcome counts, per-input-script SHA-256 (`28_generate_full_100ns_measurements.py` → `29_analyze_expanded_100ns_cohort.py` → `30_physics_guided_ai_audit.py` → `31_build_expanded_source_of_truth.py` → `run_expanded_source_of_truth_pipeline.py`), and the exact Python/pandas/numpy/MDAnalysis versions used. |
| `master/README.md` | — | Defines the same geometric outcome rule (complete 0–100 ns DCD coverage + median corrected pose RMSD < 3 Å over (70,100] ns) on the larger cohort. Explicitly retrospective. |
| `master/cohort_flow.csv` | — | Inclusion counts 81 → 73 at each filter stage. |
| `master/primary_cohort_exclusions.csv` | 8 | The 8 rows (81 − 73) excluded from the primary cohort, with reasons. |
| `full_100ns_corrected_measurements.csv` | — | Full per-frame corrected measurement set feeding the master table. |
| `primary_analysis/expanded_cohort_metrics.csv`, `primary_analysis/expanded_cohort_predictions.csv` | — | Metrics and predictions on the 73-row cohort. |
| `physics_guided_ai_audit/model_comparison_metrics.csv`, `nested_lopo_predictions.csv`, `nested_model_selections.csv` | — | The model-complexity audit cited in the paper: corrected RMSD vs. nested temporal logistic/spline/random-forest/gradient-boosting, on this 73-row cohort. |

Pipeline entry point (verified SHA-256 `7d9f4e...b740` matches on disk, 2026-07-18):
`yau_competition/scripts/cad_paper_analysis/run_expanded_source_of_truth_pipeline.py`

## Locked source-of-truth (the label + features the paper's primary claims cite)

Directory: `pipeline/training/outputs/yau_recapture_screen/cad_states/same_trajectory_source_of_truth/`

| File | Rows | Purpose |
|---|---|---|
| `same_trajectory_source_of_truth.csv` | 64 | Master table: 64 discovered complexes, with flags marking the 61-row usable-feature cohort, 59-row legacy-matched cohort, and 52-row locked complete-coverage cohort. One row per complex. |
| `README.md` | — | Defines the locked label (Eq. in paper §Data and Forecasting Design) and documents the A1 outcome-redundancy audit (centroid-vs-RMSD redundancy, 0 label changes). |
| `column_dictionary.csv` | ~200 | Name/dtype/category/description for every column in the master table. |
| `cohort_flow.csv` | — | Exact inclusion counts at each filtering stage (64 → 61 → 59 → 52). |
| `coverage_exclusions.csv` | 7 | The seven trajectories excluded for ending before the nominal 100 ns window. |
| `outcome_redundancy_audit.csv` | 1 | A1 audit: RMSD-vs-centroid redundancy check across all 59 cached late outcomes. |
| `model_audit_metrics.csv` | — | Regenerated primary LOPO metrics: AUROC 0.838264, balanced accuracy 0.756410, confusion counts (26,2,11,13) on the 52-row cohort. |
| `headline_result_registry.csv` | — | Exact headline numbers quoted in the paper, keyed for citation. |
| `legacy_headline_reconciliation.csv` | — | Maps legacy (pre-lock) numbers to the current locked numbers, explaining what changed and why. |
| `validation_procedure_audit.csv` | — | Audit of the LOPO validation procedure itself. |
| `lopo_fold_model_audit.csv` | — | Per-fold leave-one-protein-out model audit. |
| `checkpoint_model_results.csv` / `checkpoint_oof_predictions.csv` | — | Model results and saved out-of-fold probabilities at each checkpoint (5/10/15/20/30 ns). |
| `analysis_lock_a3_a5.csv`, `RESULTS_LOCK_A3_A5.md` | — | The dated prospective-lock specification (A3–A5 audit stage). |
| `primary_model_validation_specification.csv` | — | Frozen spec for the primary model/validation procedure. |
| `threshold_and_robustness_sensitivity/threshold_sensitivity.csv` | — | Table \ref{tab:threshold-sensitivity}: AUROC at 5 nearby label cutoffs. |
| `threshold_and_robustness_sensitivity/non_obvious_robustness.csv` | — | Table \ref{tab:non-obvious}: AUROC on restricted "non-obvious" subsets. |
| `source_artifact_manifest.csv` | 9 | SHA-256 + shape manifest for every upstream input file (see below). **All 9 verified to match on disk, 2026-07-18.** |

Generating scripts (present, repo-relative):
`yau_competition/scripts/cad_paper_analysis/25_build_same_trajectory_source_of_truth.py`
→ `27_audit_headlines_validation_checkpoints.py`. Do not hand-edit the CSVs; rerun the scripts.

## Paper figures (the exact numbers in the manuscript)

Directory: `.../same_trajectory_source_of_truth/claim_figures/` (generated by `26_plot_locked_claim_results.py`)

| File | Purpose |
|---|---|
| `key_claim_metrics.csv` | Headline AUROCs + protein-clustered bootstrap CIs (5000 draws) for: same-trajectory corrected pose (0.860), same-trajectory pocket retention (0.714), separate-launch controls (~0.54), PBC/self-alignment coordinate-ablation controls (~0.51–0.55), locked LOPO OOF probability (0.838). |
| `paired_auroc_differences.csv` | Paired AUROC differences + CIs (e.g. corrected-vs-PBC-naive: 0.310; corrected-vs-ligand-self: 0.353), cited in §Results. |
| `checkpoint_locked_common_cohort.csv` | Checkpoint curve (Fig. checkpoint-curve) on the identical 52-row cohort. |
| `retrospective_policy_frontier.csv` / `retrospective_policy_operating_point_p05.csv` | Compute-saving/false-stop policy frontier (Table policy, Table policy-5ns). |
| `retrospective_confusion_matrix_p05.csv` | Confusion matrix at the 0.5 decision threshold. |
| `figure_key_locked_claim.png/.pdf` | Main results figure (Fig. locked-results). |
| `figure_checkpoint_and_oof.png/.pdf` | Checkpoint curve + OOF probability distribution figure. |

## Upstream raw inputs (feed into `same_trajectory_source_of_truth.csv`)

All 9 listed in `source_artifact_manifest.csv`, each hash-pinned; **verified byte-identical on disk 2026-07-18**:

- `cad_states/pocket_aware_state_20ns/pocket_aware_state_20ns_full.csv` (64 rows)
- `cad_states/pocket_aware_validation3_model_comparison/validation3_full_features.csv` (61 rows)
- `cad_states/pocket_aware_validation3_model_comparison/validation3_matched_cohort.csv` (59 rows)
- `cad_states/checkpoint_curve_and_baselines/checkpoint_curve_and_baselines_full.csv` (59 rows)
- `cad_states/same_traj_vs_independent_replica/same_traj_vs_independent_replica_full.csv` (59 rows)
- `cad_states/same_trajectory_monitoring_validation/sametraj_model_comparison_predictions.csv` (58 rows)
- `cad_states/replica_independence_audit/replica_independence_audit_full.csv` (61 rows)
- `cad_states/pocket_aware_validation2_100ns/validation2_100ns_outcomes_full.csv` (45 rows)
- `cad_states/rbe_traces_pbc_corrected.csv` (36,640 rows — raw per-frame PBC-corrected trajectory traces, the root of the whole chain)

All paths above are relative to `pipeline/training/outputs/yau_recapture_screen/`.

## What "ground truth" means here

There is no external experimental (binding/activity) dataset. The label is
self-generated from the project's own 100 ns OpenMM trajectories: pose is
"retained" if median protein-relative, PBC-corrected ligand RMSD over the
final (70,100] ns window is < 3 Å, with complete coverage required. See
`yau_aj_trajectory_triage.tex` §Data and Forecasting Design and the
`same_trajectory_source_of_truth/README.md` above for the exact rule and the
audit that it is not redundant with/superseded by the legacy two-condition
formula.
