# Prospective shadow test summary — MDR1_CRYNH:pocket12

Status: **complete**. Both checkpoints captured genuinely prospectively (before any `(70,100]` ns data existed); trajectory finished to 100 ns; outcome validated.

## Predictions vs. actual

| Checkpoint | Feature(s) | Score | Decision | Captured |
|---|---|---|---|---|
| 5 ns | corrected RMSD (3,5] = 1.569 Å | 0.717 | continue | 2026-07-22T19:10:42Z |
| 20 ns | corrected RMSD (18,20] = 2.052 Å, centroid disp. = 1.847 Å | 0.720 | continue | 2026-07-23T16:05:33Z |

**Actual outcome**: median corrected RMSD over (70,100] ns = **3.047 Å** → non-retained (locked threshold 3.0 Å). Both "continue" predictions score as incorrect under the strict decision rule.

## Review: is this a confident miss or a boundary case?

The margin is 0.047 Å (~1.6%) past the 3.0 Å cutoff — inside the sensitivity band the manuscript already validated. Per the existing threshold-sensitivity sweep (`yau_aj.tex`, "The 3 Å outcome threshold is not fragile" / Table threshold-sensitivity), cutoffs from 2.0–5.0 Å were tested on the locked retrospective cohort; 3.5–4.0 Å preserve or slightly improve AUROC relative to 3.0 Å. At any of those already-validated alternative cutoffs (≥3.05 Å), this single case flips from non-retained to retained and both predictions score correct.

**Conclusion**: not a confident false positive. It's one prospective case landing within known measurement/threshold noise of a cutoff the paper never claimed was uniquely correct. Do not use this single point to justify moving the locked 3.0 Å threshold after the fact (that would be exactly the kind of post-hoc threshold search the manuscript's honesty framing explicitly avoids elsewhere). The defensible framing for the paper: report the raw result (2 prospective "continue" calls, actual 3.047 Å, scored incorrect at the locked 3.0 Å cutoff), and note in the same sentence that it falls inside the already-reported threshold-sensitivity margin — not that the model or checkpoint is wrong.

## Combined shadow-test record (both trajectories tested to date)

| Trajectory | Checkpoint | Decision | Actual | Correct? |
|---|---|---|---|---|
| MDR1_CRYNH:pocket1 | 20 ns | continue (0.687) | 3.575 Å, non-retained | No — clear miss (0.575 Å past cutoff) |
| MDR1_CRYNH:pocket12 | 5 ns | continue (0.717) | 3.047 Å, non-retained | No — boundary miss (0.047 Å past cutoff) |
| MDR1_CRYNH:pocket12 | 20 ns | continue (0.720) | 3.047 Å, non-retained | No — boundary miss (0.047 Å past cutoff) |

n=2 trajectories, 3 checkpoint predictions, 0/3 correct under the strict rule — but one is a clean miss and two are boundary cases on the same trajectory. Honest reporting for the paper: small-n prospective demonstration, not a validated error rate; both failure modes documented rather than selected.

Source artifacts (unmodified, hash-audited): `captures/MDR1_CRYNH__Milbemycin__pocket12__replica_1__same_trajectory_checkpoint_{5,20}ns_v1.json`, `outcome_validation_MDR1_CRYNH__Milbemycin__pocket12__replica_1.json`.
