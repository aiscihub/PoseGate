#!/usr/bin/env python3
"""Freeze, monitor, and capture prospective same-trajectory shadow decisions
at the 5 ns candidate checkpoint.

This is the 5 ns counterpart to ``prospective_shadow_monitor.py`` (the locked
20 ns primary monitor). The manuscript's own checkpoint-curve analysis
(``checkpoint_model_results.csv``, row ``checkpoint_ns=5``) is the frozen
specification turned into a workflow here: single-feature model on
``same_traj_pose_rmsd_5ns_A`` (mean corrected RMSD over the (3,5] ns window),
StandardScaler + class-weighted L2 logistic regression fit on all 52 locked
development rows, fixed 0.5 threshold. This is a *different* checkpoint lock
from the 20 ns monitor (``same_trajectory_checkpoint_5ns_v1`` vs.
``same_trajectory_checkpoint_20ns_v1``); both can run against the same or
different replicas without collision, since capture files are namespaced by
checkpoint lock ID.

Differences from the 20 ns monitor, both required by the 5 ns checkpoint
itself:
  - Single feature (corrected RMSD only), matching the locked 5 ns row in
    checkpoint_model_results.csv, not the two-feature 20 ns policy model.
  - Readiness is gated on trajectory frame count directly, not on a
    fingerprint-reporter artifact file: the online fingerprint reporter only
    emits even-numbered-ns summaries (2, 4, 6, ...), so no exact 5.0 ns
    artifact exists to poll for.

1. freeze one final all-development-data scaler/model pair (5 ns spec);
2. watch one exact 100 ns replica until production starts;
3. wait until its own trajectory exposes >= 5 ns of frames;
4. measure only its prefix through 5 ns;
5. write one immutable prediction record before 70 ns data exist.

The prediction is a same-trajectory monitoring decision, not evidence of
independent-replica or external generalization. The class-weighted logistic
``predict_proba`` output is stored as an uncalibrated score.

Examples
--------
Freeze the model once::

    python 50_prospective_shadow_monitor_5ns.py freeze-model

Monitor a new run::

    python 50_prospective_shadow_monitor_5ns.py monitor \
      --protein MDR1_CRYNH --pocket pocket12 --ligand Milbemycin
"""

from __future__ import annotations

import argparse
import csv
import fcntl
import hashlib
import json
import logging
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from typing import Any
import warnings

import joblib
import MDAnalysis as mda
from MDAnalysis.analysis.align import rotation_matrix
from MDAnalysis.lib.distances import minimize_vectors
import numpy as np
import pandas as pd
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


SCRIPT_PATH = Path(__file__).resolve()
REPO_ROOT = SCRIPT_PATH.parents[3]
BASE_100NS = Path("/media/zhenli/datadrive/valleyfevermutation/simulation_100ns_md_reruns")

LOCKED_RESULT_DIR = (
    REPO_ROOT
    / "pipeline/training/outputs/yau_recapture_screen/cad_states/"
    "same_trajectory_source_of_truth"
)
LOCKED_TABLE = LOCKED_RESULT_DIR / "same_trajectory_source_of_truth.csv"
LOCKED_SPEC = LOCKED_RESULT_DIR / "checkpoint_model_results.csv"
ANALYSIS_LOCK = LOCKED_RESULT_DIR / "analysis_lock_a3_a5.csv"

SHADOW_ROOT = REPO_ROOT / "yau_competition/prospective_shadow"
MODEL_DIR = SHADOW_ROOT / "frozen_model"
MODEL_PATH = MODEL_DIR / "same_trajectory_checkpoint_5ns_v1.joblib"
MODEL_MANIFEST_PATH = MODEL_DIR / "same_trajectory_checkpoint_5ns_v1.manifest.json"
CAPTURE_DIR = SHADOW_ROOT / "captures"
EVENT_DIR = SHADOW_ROOT / "events"
STATE_DIR = SHADOW_ROOT / "state"
LOG_DIR = SHADOW_ROOT / "monitor_logs"
PREDICTION_INDEX = SHADOW_ROOT / "shadow_predictions_5ns.csv"

ANALYSIS_ID = "same_trajectory_triage_a3_a5_v1_2026-07-15"
CHECKPOINT_LOCK_ID = "same_trajectory_checkpoint_5ns_v1"
OUTCOME_DEFINITION_ID = "late_pose_retained_rmsd_v1"
CHECKPOINT_NS = 5.0
WINDOW_START_NS = 3.0
LATE_WINDOW_START_NS = 70.0
DECISION_THRESHOLD = 0.5
LIGAND_RESNAME = "UNK"
EXPECTED_TRAIN_N = 52
EXPECTED_TRAIN_PROTEINS = 15
EXPECTED_RETAINED = 13
EXPECTED_NONRETAINED = 39
PRIMARY_FEATURES = ("same_traj_pose_rmsd_5ns_A",)


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def git_snapshot() -> dict[str, Any]:
    def run(*args: str) -> str:
        completed = subprocess.run(
            ["git", *args],
            cwd=REPO_ROOT,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return completed.stdout.strip()

    head = run("rev-parse", "HEAD")
    status = run("status", "--porcelain=v1", "--untracked-files=all")
    return {
        "git_head": head,
        "repository_dirty": bool(status),
        "git_status_sha256": hashlib.sha256(status.encode()).hexdigest(),
    }


def atomic_json(path: Path, value: dict[str, Any], *, immutable: bool) -> None:
    """Create JSON atomically, refusing to replace an existing immutable record."""
    path.parent.mkdir(parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | (os.O_EXCL if immutable else os.O_TRUNC)
    fd = os.open(path, flags, 0o644)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
    except Exception:
        path.unlink(missing_ok=True)
        raise
    if immutable:
        path.chmod(0o444)


def slug_for(protein: str, pocket: str, ligand: str, replica: str) -> str:
    return "__".join((protein, ligand, pocket, replica))


def complex_id_for(protein: str, pocket: str, ligand: str, replica: str) -> str:
    return "|".join((protein, ligand, pocket, replica))


def replica_dir_for(root: Path, protein: str, pocket: str, replica: str) -> Path:
    return root / protein / "simulation_explicit" / pocket / replica


def find_production_inputs(replica_dir: Path) -> tuple[Path, Path] | None:
    trajectories = sorted(replica_dir.glob("*_explicit_trajectory.dcd"))
    topologies = sorted(
        path
        for path in replica_dir.glob("*_explicit_initial_frame.pdb")
        if not path.name.endswith("_stripped_initial_frame.pdb")
    )
    if not trajectories or not topologies:
        return None
    if len(trajectories) != 1 or len(topologies) != 1:
        raise RuntimeError(
            f"expected one topology and trajectory in {replica_dir}; "
            f"found topology={len(topologies)}, trajectory={len(trajectories)}"
        )
    return topologies[0], trajectories[0]


def load_locked_training_table() -> pd.DataFrame:
    required_paths = (LOCKED_TABLE, LOCKED_SPEC, ANALYSIS_LOCK)
    missing = [str(path) for path in required_paths if not path.exists()]
    if missing:
        raise FileNotFoundError(f"locked analysis artifacts are missing: {missing}")

    table = pd.read_csv(LOCKED_TABLE)
    required_columns = {
        "complex_id",
        "protein",
        "eligible_locked_primary_pose_model",
        "late_pose_retained_locked",
        *PRIMARY_FEATURES,
    }
    absent = sorted(required_columns.difference(table.columns))
    if absent:
        raise ValueError(f"locked table is missing columns: {absent}")

    eligible = table["eligible_locked_primary_pose_model"].fillna(False).astype(bool)
    train = table.loc[eligible].copy()
    train["late_pose_retained_locked"] = train["late_pose_retained_locked"].astype(int)

    observed = {
        "n": len(train),
        "proteins": train["protein"].nunique(),
        "retained": int(train["late_pose_retained_locked"].sum()),
        "nonretained": int((train["late_pose_retained_locked"] == 0).sum()),
    }
    expected = {
        "n": EXPECTED_TRAIN_N,
        "proteins": EXPECTED_TRAIN_PROTEINS,
        "retained": EXPECTED_RETAINED,
        "nonretained": EXPECTED_NONRETAINED,
    }
    if observed != expected:
        raise ValueError(f"locked training cohort changed: {observed} != {expected}")
    if train[list(PRIMARY_FEATURES)].isna().any().any():
        raise ValueError("locked training cohort has missing primary features")
    return train.sort_values("complex_id").reset_index(drop=True)


def freeze_model() -> dict[str, Any]:
    """Create or verify the one final model used for all 5 ns shadow predictions."""
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    if MODEL_PATH.exists() or MODEL_MANIFEST_PATH.exists():
        if not MODEL_PATH.exists() or not MODEL_MANIFEST_PATH.exists():
            raise RuntimeError("frozen model bundle is incomplete; refusing to repair silently")
        manifest = json.loads(MODEL_MANIFEST_PATH.read_text())
        observed_hash = sha256_file(MODEL_PATH)
        if observed_hash != manifest["model_artifact_sha256"]:
            raise RuntimeError("frozen model hash does not match its manifest")
        if sha256_file(LOCKED_TABLE) != manifest["locked_training_table_sha256"]:
            raise RuntimeError("locked training table changed after model freeze")
        return manifest

    train = load_locked_training_table()
    scaler = StandardScaler(with_mean=True, with_std=True)
    x = scaler.fit_transform(train[list(PRIMARY_FEATURES)].to_numpy(dtype=float))
    y = train["late_pose_retained_locked"].to_numpy(dtype=int)
    model = LogisticRegression(
        penalty="l2",
        C=1.0,
        fit_intercept=True,
        class_weight="balanced",
        solver="lbfgs",
        max_iter=100,
        tol=1e-4,
        random_state=7,
    )
    model.fit(x, y)
    if int(model.n_iter_[0]) >= model.max_iter:
        raise RuntimeError("deployment model hit its iteration limit")

    training_ids = train["complex_id"].tolist()
    bundle = {
        "analysis_id": ANALYSIS_ID,
        "checkpoint_lock_id": CHECKPOINT_LOCK_ID,
        "outcome_definition_id": OUTCOME_DEFINITION_ID,
        "features": list(PRIMARY_FEATURES),
        "decision_threshold": DECISION_THRESHOLD,
        "score_interpretation": "uncalibrated retention score",
        "scaler": scaler,
        "model": model,
    }
    temporary_model = MODEL_PATH.with_suffix(".joblib.tmp")
    joblib.dump(bundle, temporary_model)
    os.replace(temporary_model, MODEL_PATH)
    MODEL_PATH.chmod(0o444)

    manifest = {
        "schema_version": 1,
        "created_utc": utc_now(),
        "analysis_id": ANALYSIS_ID,
        "checkpoint_lock_id": CHECKPOINT_LOCK_ID,
        "outcome_definition_id": OUTCOME_DEFINITION_ID,
        "checkpoint_ns": CHECKPOINT_NS,
        "feature_window_ns": "(3,5]",
        "features": list(PRIMARY_FEATURES),
        "decision_threshold": DECISION_THRESHOLD,
        "decision_rule": "continue if uncalibrated_retention_score >= 0.5; stop otherwise",
        "model": {
            "scaler": "StandardScaler(with_mean=True, with_std=True)",
            "estimator": "LogisticRegression",
            "penalty": "l2",
            "C": 1.0,
            "class_weight": "balanced",
            "solver": "lbfgs",
            "max_iter": 100,
            "tol": 1e-4,
            "random_state": 7,
            "score_calibrated": False,
        },
        "training_cohort": {
            "n": len(train),
            "proteins": train["protein"].nunique(),
            "retained": int(y.sum()),
            "nonretained": int((y == 0).sum()),
            "complex_ids_sha256": sha256_json(training_ids),
        },
        "fitted_parameters": {
            "scaler_mean": scaler.mean_.tolist(),
            "scaler_scale": scaler.scale_.tolist(),
            "coef_standardized": model.coef_[0].tolist(),
            "intercept": float(model.intercept_[0]),
            "n_iter": int(model.n_iter_[0]),
        },
        "model_artifact_path": str(MODEL_PATH.relative_to(REPO_ROOT)),
        "model_artifact_sha256": sha256_file(MODEL_PATH),
        "locked_training_table_path": str(LOCKED_TABLE.relative_to(REPO_ROOT)),
        "locked_training_table_sha256": sha256_file(LOCKED_TABLE),
        "locked_spec_sha256": sha256_file(LOCKED_SPEC),
        "analysis_lock_sha256": sha256_file(ANALYSIS_LOCK),
        "capture_script_sha256_at_freeze": sha256_file(SCRIPT_PATH),
        "software": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scikit_learn": sklearn.__version__,
            "MDAnalysis": mda.__version__,
        },
        **git_snapshot(),
        "limitations": [
            "Final model is fit on all locked development rows and has no independent calibration set.",
            "Shadow use is same-trajectory temporal monitoring, not independent-replica validation.",
            "The 0.5 threshold is a fixed default, not a guaranteed false-stop ceiling.",
            "5 ns was identified as the strongest candidate checkpoint after examining the full "
            "checkpoint curve on the locked cohort; this shadow capture is the first prospective "
            "test of that candidate, not a repeat of an already-prespecified plan.",
        ],
    }
    atomic_json(MODEL_MANIFEST_PATH, manifest, immutable=True)
    return manifest


def measure_prefix(
    topology: Path,
    trajectory: Path,
    *,
    require_pre70: bool = True,
) -> dict[str, Any]:
    """Measure corrected pose using only frames through the 5 ns checkpoint."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        universe = mda.Universe(str(topology), str(trajectory))
    ca = universe.select_atoms("protein and name CA")
    ligand = universe.select_atoms(f"resname {LIGAND_RESNAME} and not name H*")
    if ca.n_atoms == 0 or ligand.n_atoms == 0:
        raise ValueError(f"missing selection: CA={ca.n_atoms}, ligand={ligand.n_atoms}")

    dt_ns = float(getattr(universe.trajectory, "dt", 200.0)) / 1000.0
    if not np.isfinite(dt_ns) or dt_ns <= 0:
        dt_ns = 0.2

    available_frames = len(universe.trajectory)
    available_end_ns = available_frames * dt_ns
    if require_pre70 and available_end_ns >= LATE_WINDOW_START_NS:
        raise RuntimeError(
            f"trajectory already exposes {available_end_ns:.3f} ns; "
            "prospective capture requires less than 70 ns"
        )
    required_frames = int(round(CHECKPOINT_NS / dt_ns))
    if available_frames < required_frames:
        raise RuntimeError(
            f"checkpoint incomplete: frames={available_frames}, "
            f"required={required_frames}, end={available_end_ns:.3f} ns"
        )

    rmsd_window: list[float] = []
    displacement_window: list[float] = []
    prefix_digest = hashlib.sha256()
    reference_ca_centered = None
    reference_ligand_relative = None
    frames_used = 0

    for frame_index, ts in enumerate(universe.trajectory):
        time_ns = (frame_index + 1) * dt_ns
        if time_ns > CHECKPOINT_NS + 1e-4:
            break
        box = ts.dimensions
        if box is None or len(box) < 3 or np.any(np.asarray(box[:3]) <= 0):
            raise ValueError(f"invalid periodic box at frame {frame_index}")

        ca_positions = ca.positions
        protein_center = ca_positions.mean(axis=0)
        ligand_relative = minimize_vectors(ligand.positions - protein_center, box=box)
        ca_centered = ca_positions - protein_center
        prefix_digest.update(np.asarray(box, dtype="<f4").tobytes())
        prefix_digest.update(np.asarray(ca_positions, dtype="<f4").tobytes())
        prefix_digest.update(np.asarray(ligand.positions, dtype="<f4").tobytes())
        frames_used += 1

        if frame_index == 0:
            reference_ca_centered = ca_centered.copy()
            reference_ligand_relative = ligand_relative.copy()
            continue

        rotation, _ = rotation_matrix(ca_centered, reference_ca_centered)
        ligand_aligned = ligand_relative @ rotation.T
        delta = ligand_aligned - reference_ligand_relative
        pose_rmsd = float(np.sqrt(np.mean(np.sum(delta * delta, axis=1))))
        centroid_displacement = float(np.linalg.norm(delta.mean(axis=0)))
        if WINDOW_START_NS < time_ns <= CHECKPOINT_NS + 1e-4:
            rmsd_window.append(pose_rmsd)
            displacement_window.append(centroid_displacement)

    if frames_used != required_frames:
        raise RuntimeError(
            f"prefix read was incomplete: used={frames_used}, required={required_frames}"
        )
    if not rmsd_window or len(rmsd_window) != len(displacement_window):
        raise RuntimeError("locked feature window is empty or inconsistent")

    return {
        "corrected_pose_rmsd_mean_3_5_A": float(np.mean(rmsd_window)),
        "corrected_centroid_displacement_mean_3_5_A": float(np.mean(displacement_window)),
        "feature_window_frame_count": len(rmsd_window),
        "prefix_frames_used": frames_used,
        "frame_interval_ns": dt_ns,
        "checkpoint_end_ns": frames_used * dt_ns,
        "max_available_time_ns_at_capture": available_end_ns,
        "trajectory_frames_available_at_capture": available_frames,
        "prefix_coordinates_sha256": prefix_digest.hexdigest(),
    }


def load_frozen_bundle() -> tuple[dict[str, Any], dict[str, Any]]:
    manifest = freeze_model()
    bundle = joblib.load(MODEL_PATH)
    if bundle["checkpoint_lock_id"] != CHECKPOINT_LOCK_ID:
        raise RuntimeError("frozen model checkpoint lock mismatch")
    return bundle, manifest


def capture_path_for(slug: str) -> Path:
    return CAPTURE_DIR / f"{slug}__{CHECKPOINT_LOCK_ID}.json"


def rebuild_prediction_index() -> None:
    rows: list[dict[str, Any]] = []
    for path in sorted(CAPTURE_DIR.glob(f"*__{CHECKPOINT_LOCK_ID}.json")):
        record = json.loads(path.read_text())
        rows.append(
            {
                "prediction_id": record["prediction_id"],
                "complex_id": record["complex_id"],
                "protein_id": record["protein_id"],
                "checkpoint_ns": record["checkpoint_ns"],
                "corrected_pose_rmsd_mean_3_5_A": record["corrected_pose_rmsd_mean_3_5_A"],
                "uncalibrated_retention_score": record["uncalibrated_retention_score"],
                "decision_threshold": record["decision_threshold"],
                "stop_continue_decision": record["stop_continue_decision"],
                "timestamp_utc": record["timestamp_utc"],
                "analysis_git_commit": record["analysis_git_commit"],
                "model_artifact_sha256": record["model_artifact_sha256"],
                "capture_record": str(path.relative_to(REPO_ROOT)),
            }
        )
    PREDICTION_INDEX.parent.mkdir(parents=True, exist_ok=True)
    temporary = PREDICTION_INDEX.with_suffix(".csv.tmp")
    fields = [
        "prediction_id",
        "complex_id",
        "protein_id",
        "checkpoint_ns",
        "corrected_pose_rmsd_mean_3_5_A",
        "uncalibrated_retention_score",
        "decision_threshold",
        "stop_continue_decision",
        "timestamp_utc",
        "analysis_git_commit",
        "model_artifact_sha256",
        "capture_record",
    ]
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, PREDICTION_INDEX)


def capture_prediction(
    *, root: Path, protein: str, pocket: str, ligand: str, replica: str
) -> dict[str, Any]:
    slug = slug_for(protein, pocket, ligand, replica)
    output_path = capture_path_for(slug)
    if output_path.exists():
        return json.loads(output_path.read_text())

    replica_dir = replica_dir_for(root, protein, pocket, replica)
    inputs = find_production_inputs(replica_dir)
    if inputs is None:
        raise RuntimeError(f"production inputs have not started in {replica_dir}")
    topology, trajectory = inputs

    bundle, manifest = load_frozen_bundle()
    target_complex_id = complex_id_for(protein, pocket, ligand, replica)
    training = load_locked_training_table()
    if target_complex_id in set(training["complex_id"]):
        raise RuntimeError(
            f"target {target_complex_id} is already in the locked development cohort"
        )

    measurements = measure_prefix(topology, trajectory, require_pre70=True)
    x = np.array(
        [[measurements["corrected_pose_rmsd_mean_3_5_A"]]],
        dtype=float,
    )
    scaled = bundle["scaler"].transform(x)
    score = float(bundle["model"].predict_proba(scaled)[0, 1])
    decision = "continue" if score >= DECISION_THRESHOLD else "stop"
    captured_at = utc_now()
    snapshot = git_snapshot()
    prediction_id = (
        f"shadow-{slug}-{CHECKPOINT_LOCK_ID}-"
        f"{captured_at.replace(':', '').replace('-', '')}"
    )
    record = {
        "schema_version": 1,
        "prediction_id": prediction_id,
        "complex_id": target_complex_id,
        "protein_id": protein,
        "ligand": ligand,
        "pocket": pocket,
        "replica": replica,
        "checkpoint_lock_id": CHECKPOINT_LOCK_ID,
        "checkpoint_ns": CHECKPOINT_NS,
        "feature_window_ns": "(3,5]",
        **measurements,
        "uncalibrated_retention_score": score,
        "score_calibrated": False,
        "decision_threshold": DECISION_THRESHOLD,
        "stop_continue_decision": decision,
        "decision_is_shadow_only": True,
        "simulation_must_continue_to_100ns": True,
        "late_outcome_accessed": False,
        "outcome_embargo_until_ns": LATE_WINDOW_START_NS,
        "timestamp_utc": captured_at,
        "hostname": socket.gethostname(),
        "analysis_id": ANALYSIS_ID,
        "outcome_definition_id": OUTCOME_DEFINITION_ID,
        "analysis_git_commit": snapshot["git_head"],
        "repository_dirty": snapshot["repository_dirty"],
        "git_status_sha256": snapshot["git_status_sha256"],
        "capture_script_sha256": sha256_file(SCRIPT_PATH),
        "model_manifest_path": str(MODEL_MANIFEST_PATH.relative_to(REPO_ROOT)),
        "model_manifest_sha256": sha256_file(MODEL_MANIFEST_PATH),
        "model_artifact_sha256": manifest["model_artifact_sha256"],
        "locked_training_table_sha256": manifest["locked_training_table_sha256"],
        "topology_path": str(topology),
        "topology_sha256": sha256_file(topology),
        "trajectory_path": str(trajectory),
        "trajectory_size_bytes_at_capture": trajectory.stat().st_size,
        "interpretation_limit": (
            "Small prospective same-trajectory shadow demonstration of the 5 ns candidate "
            "checkpoint; not proof of independent-replica, external, binding, or biological "
            "generalization, and not yet a repeated/multi-run prospective test."
        ),
    }
    atomic_json(output_path, record, immutable=True)
    rebuild_prediction_index()
    return record


def write_start_event(*, slug: str, complex_id: str, topology: Path, trajectory: Path) -> Path:
    path = EVENT_DIR / f"{slug}__{CHECKPOINT_LOCK_ID}__production_start_detected.json"
    if path.exists():
        return path
    stat = trajectory.stat()
    record = {
        "schema_version": 1,
        "event": "production_start_detected",
        "complex_id": complex_id,
        "detected_utc": utc_now(),
        "topology_path": str(topology),
        "trajectory_path": str(trajectory),
        "trajectory_size_bytes_at_detection": stat.st_size,
        "trajectory_mtime_ns_at_detection": stat.st_mtime_ns,
        "capture_script_sha256": sha256_file(SCRIPT_PATH),
        **git_snapshot(),
    }
    atomic_json(path, record, immutable=True)
    return path


def configure_logging(slug: str, verbose: bool) -> logging.Logger:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger(f"shadow-monitor-5ns-{slug}")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    file_handler = logging.FileHandler(LOG_DIR / f"{slug}__5ns.log")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(stream_handler)
    return logger


def monitor(
    *,
    root: Path,
    protein: str,
    pocket: str,
    ligand: str,
    replica: str,
    poll_seconds: float,
    verbose: bool,
) -> dict[str, Any]:
    slug = slug_for(protein, pocket, ligand, replica)
    logger = configure_logging(slug, verbose)
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    lock_path = STATE_DIR / f"{slug}__{CHECKPOINT_LOCK_ID}.lock"
    pid_path = STATE_DIR / f"{slug}__{CHECKPOINT_LOCK_ID}.pid"
    lock_handle = lock_path.open("a+")
    try:
        fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError(f"another monitor already holds {lock_path}") from exc
    pid_path.write_text(f"{os.getpid()}\n")

    try:
        manifest = freeze_model()
        logger.info("Frozen 5 ns model ready: sha256=%s", manifest["model_artifact_sha256"])
        output_path = capture_path_for(slug)
        if output_path.exists():
            logger.info("Capture already exists; exiting: %s", output_path)
            return json.loads(output_path.read_text())

        replica_dir = replica_dir_for(root, protein, pocket, replica)
        logger.info("Watching %s for >= %.1f ns", replica_dir, CHECKPOINT_NS)
        last_status_time = 0.0
        while True:
            inputs = find_production_inputs(replica_dir)
            now = time.monotonic()
            if inputs is None:
                if now - last_status_time >= 900 or last_status_time == 0:
                    logger.info("Waiting for production trajectory to start")
                    last_status_time = now
                time.sleep(poll_seconds)
                continue

            topology, trajectory = inputs
            complex_id = complex_id_for(protein, pocket, ligand, replica)
            event_path = write_start_event(
                slug=slug, complex_id=complex_id, topology=topology, trajectory=trajectory
            )
            if now - last_status_time >= 900 or last_status_time == 0:
                logger.info("Production start detected; event=%s", event_path)

            try:
                record = capture_prediction(
                    root=root, protein=protein, pocket=pocket, ligand=ligand, replica=replica
                )
                logger.info(
                    "CAPTURED decision=%s score=%.9f record=%s",
                    record["stop_continue_decision"],
                    record["uncalibrated_retention_score"],
                    output_path,
                )
                return record
            except RuntimeError as exc:
                if "checkpoint incomplete" in str(exc):
                    if now - last_status_time >= 900 or last_status_time == 0:
                        logger.info("Waiting for %.1f ns of frames: %s", CHECKPOINT_NS, exc)
                        last_status_time = now
                    time.sleep(poll_seconds)
                    continue
                raise
            except OSError as exc:
                # OpenMM's DCDReporter creates the trajectory file as soon as it is
                # attached, before any frame is flushed, so find_production_inputs()
                # can see the file exist slightly before it has a valid DCD header.
                # This is transient, not a real failure: keep polling.
                if "premature EOF" in str(exc) or "DCD header" in str(exc):
                    if now - last_status_time >= 900 or last_status_time == 0:
                        logger.info("Trajectory file exists but header not yet valid: %s", exc)
                        last_status_time = now
                    time.sleep(poll_seconds)
                    continue
                raise
    finally:
        pid_path.unlink(missing_ok=True)
        fcntl.flock(lock_handle, fcntl.LOCK_UN)
        lock_handle.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("freeze-model", help="freeze or verify the deployment model")

    def add_target_arguments(target: argparse.ArgumentParser) -> None:
        target.add_argument("--root", type=Path, default=BASE_100NS)
        target.add_argument("--protein", required=True)
        target.add_argument("--pocket", required=True)
        target.add_argument("--ligand", default="Milbemycin")
        target.add_argument("--replica", default="replica_1")

    measure_parser = subparsers.add_parser("measure", help="measure a prefix only")
    add_target_arguments(measure_parser)

    capture_parser = subparsers.add_parser("capture", help="capture one prediction now")
    add_target_arguments(capture_parser)

    monitor_parser = subparsers.add_parser("monitor", help="watch and capture once")
    add_target_arguments(monitor_parser)
    monitor_parser.add_argument("--poll-seconds", type=float, default=60.0)
    monitor_parser.add_argument("--verbose", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.command == "freeze-model":
        print(json.dumps(freeze_model(), indent=2, sort_keys=True))
        return

    replica_dir = replica_dir_for(args.root, args.protein, args.pocket, args.replica)
    if args.command == "measure":
        inputs = find_production_inputs(replica_dir)
        if inputs is None:
            raise SystemExit(f"production inputs not found in {replica_dir}")
        print(json.dumps(measure_prefix(*inputs, require_pre70=False), indent=2, sort_keys=True))
        return
    if args.command == "capture":
        record = capture_prediction(
            root=args.root, protein=args.protein, pocket=args.pocket,
            ligand=args.ligand, replica=args.replica,
        )
        print(json.dumps(record, indent=2, sort_keys=True))
        return
    if args.command == "monitor":
        record = monitor(
            root=args.root, protein=args.protein, pocket=args.pocket, ligand=args.ligand,
            replica=args.replica, poll_seconds=args.poll_seconds, verbose=args.verbose,
        )
        print(json.dumps(record, indent=2, sort_keys=True))
        return
    raise AssertionError(f"unhandled command: {args.command}")


if __name__ == "__main__":
    main()
