#!/usr/bin/env python3
"""Close the loop on a completed prospective shadow trajectory.

MDR1_CRYNH:pocket1 was used for the 20 ns shadow-monitor demonstration on
2026-07-19 (prospective_shadow/captures/...same_trajectory_checkpoint_20ns_v1.json,
decision "continue", score 0.687). The simulation itself finished cleanly to
100.1 ns on 2026-07-19 21:18 (confirmed directly from its simulation.log),
but this trajectory was never run through the main analysis pipeline
(rbe_traces_pbc_corrected.csv has no row for it -- it simply post-dates the
last full sweep), so the source-of-truth table shows
trajectory_n_frames_audited=0 for it and its actual late-window outcome has
never been computed. The shadow prediction was therefore never checked
against reality.

This script computes that outcome directly from the raw trajectory, using
the identical per-frame procedure (protein-CA Kabsch alignment + minimum-
image ligand correction) as the locked pipeline and the shadow monitor
itself, and reports whether any genuine 5 ns and 20 ns captures were correct.
If no genuine 5 ns capture exists, it also replays what the frozen 5 ns
candidate model would have scored, clearly labeling that result as
retrospective context rather than a prospective prediction.

This is a read-only diagnostic: it does not modify
same_trajectory_source_of_truth.csv, rbe_traces_pbc_corrected.csv, or any
other locked artifact. It writes one new file,
prospective_shadow/outcome_validation_<slug>.json.

Usage:
    python 51_validate_shadow_outcome.py --protein MDR1_CRYNH --pocket pocket1 \
        --ligand Milbemycin
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
import warnings
from pathlib import Path
from typing import Any

import joblib
import MDAnalysis as mda
from MDAnalysis.analysis.align import rotation_matrix
from MDAnalysis.lib.distances import minimize_vectors
import numpy as np

from common import REPO_ROOT

BASE_100NS = Path("/media/zhenli/datadrive/valleyfevermutation/simulation_100ns_md")
SHADOW_ROOT = REPO_ROOT / "yau_competition/prospective_shadow"
LIGAND_RESNAME = "UNK"
LATE_WINDOW_START_NS = 70.0
LATE_WINDOW_END_NS = 100.0
RETENTION_THRESHOLD_A = 3.0


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def find_production_inputs(replica_dir: Path) -> tuple[Path, Path]:
    trajectories = sorted(replica_dir.glob("*_explicit_trajectory.dcd"))
    topologies = sorted(
        p for p in replica_dir.glob("*_explicit_initial_frame.pdb")
        if not p.name.endswith("_stripped_initial_frame.pdb")
    )
    if len(trajectories) != 1 or len(topologies) != 1:
        raise RuntimeError(
            f"expected exactly one topology+trajectory in {replica_dir}; "
            f"found topology={len(topologies)}, trajectory={len(trajectories)}"
        )
    return topologies[0], trajectories[0]


def compute_full_trace(topology: Path, trajectory: Path) -> dict[str, Any]:
    """Corrected ligand RMSD at every saved frame, identical procedure to the
    locked pipeline: protein-CA Kabsch alignment to frame 0, minimum-image
    ligand correction relative to the protein centroid."""
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        universe = mda.Universe(str(topology), str(trajectory))
    ca = universe.select_atoms("protein and name CA")
    ligand = universe.select_atoms(f"resname {LIGAND_RESNAME} and not name H*")
    if ca.n_atoms == 0 or ligand.n_atoms == 0:
        raise ValueError(f"missing selection: CA={ca.n_atoms}, ligand={ligand.n_atoms}")

    dt_ns = float(getattr(universe.trajectory, "dt", 200.0)) / 1000.0
    if not np.isfinite(dt_ns) or dt_ns <= 0:
        dt_ns = 0.2

    times_ns: list[float] = []
    rmsd_trace: list[float] = []
    reference_ca_centered = None
    reference_ligand_relative = None

    for frame_index, ts in enumerate(universe.trajectory):
        time_ns = (frame_index + 1) * dt_ns
        box = ts.dimensions
        if box is None or len(box) < 3 or np.any(np.asarray(box[:3]) <= 0):
            raise ValueError(f"invalid periodic box at frame {frame_index}")

        ca_positions = ca.positions
        protein_center = ca_positions.mean(axis=0)
        ligand_relative = minimize_vectors(ligand.positions - protein_center, box=box)
        ca_centered = ca_positions - protein_center

        if frame_index == 0:
            reference_ca_centered = ca_centered.copy()
            reference_ligand_relative = ligand_relative.copy()
            times_ns.append(time_ns)
            rmsd_trace.append(0.0)
            continue

        rotation, _ = rotation_matrix(ca_centered, reference_ca_centered)
        ligand_aligned = ligand_relative @ rotation.T
        delta = ligand_aligned - reference_ligand_relative
        pose_rmsd = float(np.sqrt(np.mean(np.sum(delta * delta, axis=1))))
        times_ns.append(time_ns)
        rmsd_trace.append(pose_rmsd)

    return {
        "times_ns": np.array(times_ns),
        "rmsd_A": np.array(rmsd_trace),
        "frame_interval_ns": dt_ns,
        "n_frames": len(times_ns),
        "trajectory_end_ns": times_ns[-1] if times_ns else 0.0,
    }


def window_mean(trace: dict[str, Any], start_ns: float, end_ns: float) -> float:
    mask = (trace["times_ns"] > start_ns) & (trace["times_ns"] <= end_ns + 1e-4)
    values = trace["rmsd_A"][mask]
    if len(values) == 0:
        raise ValueError(f"no frames in window ({start_ns},{end_ns}] ns")
    return float(np.mean(values))


def window_median(trace: dict[str, Any], start_ns: float, end_ns: float) -> float:
    mask = (trace["times_ns"] > start_ns) & (trace["times_ns"] <= end_ns + 1e-4)
    values = trace["rmsd_A"][mask]
    if len(values) == 0:
        raise ValueError(f"no frames in window ({start_ns},{end_ns}] ns")
    return float(np.median(values))


def score_with_frozen_model(model_path: Path, feature_values: list[float]) -> float:
    bundle = joblib.load(model_path)
    x = np.array([feature_values], dtype=float)
    scaled = bundle["scaler"].transform(x)
    return float(bundle["model"].predict_proba(scaled)[0, 1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protein", required=True)
    parser.add_argument("--pocket", required=True)
    parser.add_argument("--ligand", default="Milbemycin")
    parser.add_argument("--replica", default="replica_1")
    parser.add_argument("--root", type=Path, default=BASE_100NS)
    args = parser.parse_args()

    slug = "__".join((args.protein, args.ligand, args.pocket, args.replica))
    complex_id = "|".join((args.protein, args.ligand, args.pocket, args.replica))
    replica_dir = args.root / args.protein / "simulation_explicit" / args.pocket / args.replica
    topology, trajectory = find_production_inputs(replica_dir)

    print(f"Reading full trajectory for {complex_id} ...", file=sys.stderr)
    trace = compute_full_trace(topology, trajectory)
    print(
        f"n_frames={trace['n_frames']} end={trace['trajectory_end_ns']:.2f} ns",
        file=sys.stderr,
    )
    if trace["trajectory_end_ns"] < LATE_WINDOW_END_NS - 1.0:
        raise SystemExit(
            f"trajectory only reaches {trace['trajectory_end_ns']:.2f} ns; "
            "late outcome window is not covered"
        )

    late_median = window_median(trace, LATE_WINDOW_START_NS, LATE_WINDOW_END_NS)
    late_retained = bool(late_median < RETENTION_THRESHOLD_A)

    x5 = window_mean(trace, 3.0, 5.0)
    x18_20 = window_mean(trace, 18.0, 20.0)

    result: dict[str, Any] = {
        "schema_version": 1,
        "generated_utc": utc_now(),
        "complex_id": complex_id,
        "purpose": (
            "Outcome computation for a completed prospective shadow trajectory. "
            "It compares immutable early-coordinate forecasts with the later "
            "(70,100] ns pose-retention outcome. Read-only: does not modify any "
            "locked cohort or analysis artifact."
        ),
        "trajectory_path": str(trajectory),
        "trajectory_sha256": sha256_file(trajectory),
        "trajectory_n_frames": trace["n_frames"],
        "trajectory_end_ns": trace["trajectory_end_ns"],
        "late_pose_rmsd_median_70_100_A": late_median,
        "late_pose_retained": late_retained,
        "retention_threshold_A": RETENTION_THRESHOLD_A,
        "same_traj_pose_rmsd_5ns_A": x5,
        "same_traj_pose_rmsd_18_20_A": x18_20,
    }

    capture_20ns = (
        SHADOW_ROOT / "captures"
        / f"{slug}__same_trajectory_checkpoint_20ns_v1.json"
    )
    if capture_20ns.exists():
        capture = json.loads(capture_20ns.read_text())
        predicted_decision = capture["stop_continue_decision"]
        actually_correct_to_continue = late_retained
        result["shadow_20ns_capture"] = {
            "capture_path": str(capture_20ns.relative_to(REPO_ROOT)),
            "predicted_decision": predicted_decision,
            "predicted_score": capture["uncalibrated_retention_score"],
            "captured_pose_rmsd_18_20_A": capture["corrected_pose_rmsd_mean_18_20_A"],
            "recomputed_pose_rmsd_18_20_A": x18_20,
            "measurement_cross_check_delta_A": abs(
                x18_20 - capture["corrected_pose_rmsd_mean_18_20_A"]
            ),
            "actual_late_outcome_retained": late_retained,
            "actual_late_pose_rmsd_median_A": late_median,
            "decision_was_correct": (
                (predicted_decision == "continue" and actually_correct_to_continue)
                or (predicted_decision == "stop" and not actually_correct_to_continue)
            ),
            "note": (
                "'continue' is scored correct if the trajectory was in fact "
                "late-retained (a stopped run cannot be checked this way; only "
                "'continue' decisions are directly falsifiable against a "
                "completed run)."
            ),
        }
        print(
            f"20 ns shadow: predicted={predicted_decision} "
            f"(score={capture['uncalibrated_retention_score']:.3f}), "
            f"actual_retained={late_retained} "
            f"(late median RMSD={late_median:.3f} A), "
            f"correct={result['shadow_20ns_capture']['decision_was_correct']}",
            file=sys.stderr,
        )

    capture_5ns = (
        SHADOW_ROOT / "captures"
        / f"{slug}__same_trajectory_checkpoint_5ns_v1.json"
    )
    model_5ns = SHADOW_ROOT / "frozen_model" / "same_trajectory_checkpoint_5ns_v1.joblib"
    if capture_5ns.exists():
        capture = json.loads(capture_5ns.read_text())
        predicted_decision = capture["stop_continue_decision"]
        result["shadow_5ns_capture"] = {
            "capture_path": str(capture_5ns.relative_to(REPO_ROOT)),
            "predicted_decision": predicted_decision,
            "predicted_score": capture["uncalibrated_retention_score"],
            "captured_pose_rmsd_3_5_A": capture["corrected_pose_rmsd_mean_3_5_A"],
            "recomputed_pose_rmsd_3_5_A": x5,
            "measurement_cross_check_delta_A": abs(
                x5 - capture["corrected_pose_rmsd_mean_3_5_A"]
            ),
            "actual_late_outcome_retained": late_retained,
            "actual_late_pose_rmsd_median_A": late_median,
            "decision_was_correct": (
                (predicted_decision == "continue" and late_retained)
                or (predicted_decision == "stop" and not late_retained)
            ),
        }
        print(
            f"5 ns shadow: predicted={predicted_decision} "
            f"(score={capture['uncalibrated_retention_score']:.3f}), "
            f"actual_retained={late_retained} "
            f"(late median RMSD={late_median:.3f} A), "
            f"correct={result['shadow_5ns_capture']['decision_was_correct']}",
            file=sys.stderr,
        )
    elif model_5ns.exists():
        score_5ns = score_with_frozen_model(model_5ns, [x5])
        result["retrospective_5ns_replay"] = {
            "note": (
                "NOT a genuine prospective capture: this trajectory is long past "
                "70 ns, so this is a same-frozen-model replay on already-available "
                "data, computed purely for context."
            ),
            "same_traj_pose_rmsd_5ns_A": x5,
            "uncalibrated_retention_score": score_5ns,
            "decision_at_p05": "continue" if score_5ns >= 0.5 else "stop",
            "actual_late_outcome_retained": late_retained,
        }
        print(
            f"5 ns retrospective replay: score={score_5ns:.3f} "
            f"decision={'continue' if score_5ns >= 0.5 else 'stop'}",
            file=sys.stderr,
        )

    output_path = SHADOW_ROOT / f"outcome_validation_{slug}.json"
    output_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"Wrote {output_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
