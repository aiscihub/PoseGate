#!/bin/bash
# Pause the MDR1_CRYNH:pocket12 MD run at the exact 20.0 ns reporter boundary.
#
# The state-data reporter is ordered after both DCDReporter and
# CheckpointReporter. Therefore, observing step 5,000,000 in simulation.log
# proves that the 20.0 ns DCD frame and matching restart checkpoint were both
# written before this script stops the processes.

set -uo pipefail

PROTEIN="MDR1_CRYNH"
POCKET="pocket12"
LIGAND="Milbemycin"
TARGET_STEP=5000000
TARGET_NS="20.0"

REPO_ROOT="/home/zhenli/git/valleyfevermutation"
RUN_DIR="/media/zhenli/datadrive/valleyfevermutation/simulation_100ns_md_reruns/${PROTEIN}/simulation_explicit/${POCKET}/replica_1"
CAPTURE_PATH="${REPO_ROOT}/yau_competition/prospective_shadow/captures/${PROTEIN}__${LIGAND}__${POCKET}__replica_1__same_trajectory_checkpoint_20ns_v1.json"
PAUSE_LOG="/tmp/${PROTEIN}_${POCKET}_pause_at_20ns.log"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$PAUSE_LOG"
}

mapfile -t STATE_LOGS < <(find "$RUN_DIR" -maxdepth 1 -type f -name "*_simulation.log" -print)
mapfile -t DCD_FILES < <(find "$RUN_DIR" -maxdepth 1 -type f -name "*_trajectory.dcd" -print)
mapfile -t CHECKPOINT_FILES < <(find "$RUN_DIR" -maxdepth 1 -type f -name "*_checkpoint.chk" -print)
if [ "${#STATE_LOGS[@]}" -ne 1 ] || [ "${#DCD_FILES[@]}" -ne 1 ] || [ "${#CHECKPOINT_FILES[@]}" -ne 1 ]; then
    log "FATAL: expected exactly one state log, DCD, and checkpoint in $RUN_DIR"
    exit 2
fi
STATE_LOG="${STATE_LOGS[0]}"
DCD_FILE="${DCD_FILES[0]}"
CHECKPOINT_FILE="${CHECKPOINT_FILES[0]}"

latest_step() {
    tail -n 1 "$STATE_LOG" | cut -d, -f1
}

initial_step="$(latest_step)"
if ! [[ "$initial_step" =~ ^[0-9]+$ ]]; then
    log "FATAL: could not parse the current step from $STATE_LOG: $initial_step"
    exit 2
fi
if [ "$initial_step" -ge "$TARGET_STEP" ]; then
    log "FATAL: target step $TARGET_STEP was already reached before this watcher was armed"
    exit 3
fi

log "Armed at step=$initial_step; waiting for step=$TARGET_STEP (${TARGET_NS} ns)"

while true; do
    step="$(latest_step)"
    if [[ "$step" =~ ^[0-9]+$ ]] && [ "$step" -ge "$TARGET_STEP" ]; then
        mapfile -t WATCHDOG_PIDS < <(
            pgrep -f "^/bin/bash ./run_rerun_with_watchdog.sh ${PROTEIN} ${POCKET} ${LIGAND} 100$"
        )
        if [ "${#WATCHDOG_PIDS[@]}" -ne 1 ]; then
            log "FATAL: expected one MD watchdog at target; found ${#WATCHDOG_PIDS[@]}"
            exit 4
        fi
        watchdog_pid="${WATCHDOG_PIDS[0]}"
        mapfile -t MD_PIDS < <(pgrep -P "$watchdog_pid")
        if [ "${#MD_PIDS[@]}" -ne 1 ]; then
            log "FATAL: expected one MD child of watchdog $watchdog_pid; found ${#MD_PIDS[@]}"
            exit 5
        fi
        md_pid="${MD_PIDS[0]}"
        md_args="$(ps -p "$md_pid" -o args=)"
        if [[ "$md_args" != *"run_explicit_protein_ligand_md_v2"* ]]; then
            log "FATAL: child $md_pid is not the expected OpenMM process: $md_args"
            exit 6
        fi

        log "Target observed at state step=$step; stopping watchdog PID $watchdog_pid"
        kill "$watchdog_pid"
        log "Sending SIGTERM to OpenMM PID $md_pid"
        kill -TERM "$md_pid"

        for _ in $(seq 1 60); do
            if ! kill -0 "$md_pid" 2>/dev/null; then
                break
            fi
            sleep 1
        done
        if kill -0 "$md_pid" 2>/dev/null; then
            log "FATAL: OpenMM PID $md_pid did not exit after SIGTERM; no stronger signal sent"
            exit 7
        fi

        final_step="$(latest_step)"
        log "PAUSED: final state step=$final_step; DCD=$(stat -c %s "$DCD_FILE") bytes; checkpoint=$(stat -c %s "$CHECKPOINT_FILE") bytes"
        log "GPU is released. Leaving the independent shadow monitor running."

        while [ ! -f "$CAPTURE_PATH" ]; do
            sleep 15
        done
        log "20 ns immutable capture exists: $CAPTURE_PATH"
        exit 0
    fi
    sleep 2
done
