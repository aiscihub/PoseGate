#!/bin/bash
# Run the frozen 20 ns prospective shadow monitor, restarting it automatically
# if it exits before writing the immutable checkpoint-specific capture.
#
# Usage:
#   ./run_shadow_monitor_20ns_with_watchdog.sh PROTEIN POCKET [LIGAND] [MAX_RETRIES]

set -uo pipefail

PROTEIN="${1:?protein required}"
POCKET="${2:?pocket required}"
LIGAND="${3:-Milbemycin}"
MAX_RETRIES="${4:-200}"

REPO_ROOT="/home/zhenli/git/valleyfevermutation"
SCRIPT_DIR="${REPO_ROOT}/yau_competition/scripts/cad_paper_analysis"
RERUN_ROOT="/media/zhenli/datadrive/valleyfevermutation/simulation_100ns_md_reruns"
PYTHON="${REPO_ROOT}/venv/bin/python"
CAPTURE_PATH="${REPO_ROOT}/yau_competition/prospective_shadow/captures/${PROTEIN}__${LIGAND}__${POCKET}__replica_1__same_trajectory_checkpoint_20ns_v1.json"
LOG_PATH="/tmp/${PROTEIN}_${POCKET}_shadow20ns_watchdog.log"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG_PATH"
}

if [ -f "$CAPTURE_PATH" ]; then
    log "Capture already exists: $CAPTURE_PATH. Nothing to do."
    exit 0
fi

cd "$SCRIPT_DIR"

attempt=0
while true; do
    if [ -f "$CAPTURE_PATH" ]; then
        log "Capture complete: $CAPTURE_PATH"
        exit 0
    fi
    attempt=$((attempt + 1))
    if [ "$attempt" -gt "$MAX_RETRIES" ]; then
        log "Exceeded max retries ($MAX_RETRIES); giving up."
        exit 1
    fi
    log "Attempt ${attempt}/${MAX_RETRIES}: starting 20 ns monitor for ${PROTEIN}:${POCKET}"
    "$PYTHON" prospective_shadow_monitor.py monitor \
        --root "$RERUN_ROOT" \
        --protein "$PROTEIN" --pocket "$POCKET" --ligand "$LIGAND" \
        --poll-seconds 300 --verbose \
        >> "$LOG_PATH" 2>&1
    exit_code=$?
    log "Attempt ${attempt} exited with code ${exit_code}"
    if [ -f "$CAPTURE_PATH" ]; then
        log "Capture complete after attempt ${attempt}."
        exit 0
    fi
    log "Not yet captured; sleeping 30s before retry."
    sleep 30
done
