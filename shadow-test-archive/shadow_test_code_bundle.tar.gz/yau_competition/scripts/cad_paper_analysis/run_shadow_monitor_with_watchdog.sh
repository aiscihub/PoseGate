#!/bin/bash
# Run the 5 ns prospective shadow monitor, restarting it automatically if it
# ever dies before capturing a prediction. Safe to retry: capture_prediction()
# is idempotent (returns the existing immutable record if one was already
# written), and readiness is re-derived from the live trajectory each time,
# not from in-process state.
#
# Usage:
#   ./run_shadow_monitor_with_watchdog.sh PROTEIN POCKET [LIGAND] [MAX_RETRIES]
#
# Example:
#   nohup ./run_shadow_monitor_with_watchdog.sh MDR1_CRYNH pocket12 Milbemycin 200 \
#       > /tmp/mdr1_crynh_pocket12_shadow5ns_watchdog_stdout.log 2>&1 &

set -uo pipefail

PROTEIN="${1:?protein required}"
POCKET="${2:?pocket required}"
LIGAND="${3:-Milbemycin}"
MAX_RETRIES="${4:-200}"

REPO_ROOT="/home/zhenli/git/valleyfevermutation"
SCRIPT_DIR="${REPO_ROOT}/yau_competition/scripts/cad_paper_analysis"
CAPTURE_PATH="${REPO_ROOT}/yau_competition/prospective_shadow/captures/${PROTEIN}__${LIGAND}__${POCKET}__replica_1__same_trajectory_checkpoint_5ns_v1.json"
LOG_PATH="/tmp/${PROTEIN}_${POCKET}_shadow5ns_watchdog.log"

log() {
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG_PATH"
}

if [ -f "$CAPTURE_PATH" ]; then
    log "Capture already exists: $CAPTURE_PATH. Nothing to do."
    exit 0
fi

source /home/zhenli/miniconda3/etc/profile.d/conda.sh
conda activate openmm-env
cd "$SCRIPT_DIR"

attempt=0
while true; do
    if [ -f "$CAPTURE_PATH" ]; then
        log "Capture complete: $CAPTURE_PATH"
        exit 0
    fi
    attempt=$((attempt + 1))
    if [ "$attempt" -gt "$MAX_RETRIES" ]; then
        log "Exceeded max retries ($MAX_RETRIES); giving up."
        exit 1
    fi
    log "Attempt ${attempt}/${MAX_RETRIES}: starting monitor for ${PROTEIN}:${POCKET}"
    python 50_prospective_shadow_monitor_5ns.py monitor \
        --protein "$PROTEIN" --pocket "$POCKET" --ligand "$LIGAND" --verbose \
        >> "$LOG_PATH" 2>&1
    exit_code=$?
    log "Attempt ${attempt} exited with code ${exit_code}"
    if [ -f "$CAPTURE_PATH" ]; then
        log "Capture complete after attempt ${attempt}."
        exit 0
    fi
    log "Not yet captured; sleeping 30s before retry."
    sleep 30
done
